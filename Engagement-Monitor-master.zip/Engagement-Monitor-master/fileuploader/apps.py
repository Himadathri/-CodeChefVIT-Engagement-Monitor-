from django.apps import AppConfig


class FileuploaderConfig(AppConfig):
    name = 'fileuploader'
